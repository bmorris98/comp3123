export class Contact {
}
